package com.example.voice_autobiography_flutter

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}